<?php
$var1 = $_POST['nume'];
$var2 = $_POST['user'];

$fileHandle = fopen("mytext.txt",'w');
fwrite($fileHandle, $var1);
fwrite($fileHandle, "\r\n");
fwrite($fileHandle, $var2);
fclose($fileHandle);

echo "Multumim pentru inregistrare " . $var1;

?>
        